# Inventario Pedidos — App de recepción de mercancía

App Android nativa (Kotlin) para comprobar, con la PDA y su lector de
código de barras, que la mercancía recibida coincide con la factura del
pedido.

## Cómo funciona

1. **Importar factura**: en la pantalla principal, pulsa "Importar
   factura (CSV)" y selecciona el archivo. Debe tener 3 columnas: código,
   descripción, cantidad (con cabecera en la primera fila). Se admite
   separador por coma o por punto y coma.
   - Si el archivo original es `.xlsx`, expórtalo desde Excel como
     **"CSV UTF-8 (delimitado por comas)"**.
2. **Escanear**: la pantalla siguiente mantiene el foco en un campo de
   texto invisible al usuario, listo para recibir la lectura del lector
   de código de barras (que funciona como un teclado: escribe el código
   y pulsa "Intro" automáticamente). Cada lectura:
   - Si el código está en la factura y aún faltan unidades → suma 1 y
     lo marca en verde cuando se completa.
   - Si el código está en la factura pero ya se había completado → lo
     marca en rojo como "cantidad de más".
   - Si el código no aparece en la factura → se guarda aparte como
     "código desconocido" y también se marca en rojo.
   - Vibración corta = correcto, vibración larga = incidencia.
3. **Finalizar**: al pulsar "Finalizar recuento" se abre el resumen con
   el total de artículos, cuántos correctos, cuántos sin escanear,
   cuántos con exceso y cuántos códigos desconocidos, junto con la lista
   de incidencias para revisarlas una a una. Desde ahí puedes exportar
   un CSV con el detalle a la carpeta Descargas del dispositivo.

## Cómo abrir y compilar el proyecto

1. Instala **Android Studio** (versión Koala 2024.1 o posterior).
2. Abre Android Studio → "Open" → selecciona la carpeta `InventarioPedidos`.
3. Android Studio detectará que falta el binario del Gradle Wrapper y se
   ofrecerá a regenerarlo automáticamente (o usa Gradle incluido en el
   propio Android Studio) — solo dale a "Sync Now" cuando te lo pida.
4. Conecta la PDA por USB con la depuración USB activada, o genera un
   APK con "Build" → "Build Bundle(s) / APK(s)" → "Build APK(s)".
5. Instala el APK en la PDA (puedes copiarlo por USB o por un gestor de
   archivos si no tienes Play Store en el dispositivo).

## Supuesto importante sobre el lector de código de barras

Como me indicaste que la PDA es un Android "puro" con una app de lectura
de terceros, la app está construida asumiendo que **el lector simula un
teclado**: al leer un código, lo escribe en el campo de texto activo y
envía automáticamente una pulsación de "Intro". Esto es el
comportamiento más habitual en apps de escaneo genéricas para Android
(modo "keyboard wedge" o "HID"). Si tu app de lectura concreta funciona
de otra forma (por ejemplo, enviando un `Intent`/`broadcast` en lugar de
simular teclado), avísame y adapto `EscaneoActivity.kt` a ese mecanismo
en lugar del campo de texto — es un cambio localizado en un único
archivo, el resto de la app no cambia.

## Compilar el APK sin instalar Android Studio (GitHub Actions)

El proyecto incluye `.github/workflows/build.yml`, que compila el APK
automáticamente en la nube cada vez que subes el código a GitHub:

1. Crea un repositorio en GitHub (gratuito) y sube el contenido de esta
   carpeta (`git init`, `git add .`, `git commit`, `git push`, o
   arrastrando los archivos desde la web de GitHub).
2. En la pestaña "Actions" del repositorio verás que se lanza solo el
   flujo "Compilar APK".
3. Cuando termine (unos minutos), entra en esa ejecución y descarga el
   archivo `InventarioPedidos-debug-apk` en "Artifacts" — ahí está tu
   `.apk` listo para copiar a la PDA e instalar.

No necesito credenciales tuyas para esto: todo ocurre en tu propio
repositorio, con la compilación gestionada por GitHub, gratis para
repos personales.

## Estilo visual

La interfaz sigue una estética inspirada en HyperOS: fondo neutro
cálido, tarjetas blancas con esquinas muy redondeadas, botones grandes
sin esquinas rectas y un acento naranja como color principal. Los
colores están centralizados en `res/values/colors.xml` y las formas
redondeadas en `res/drawable/bg_*.xml`, así que es fácil ajustarlos si
quieres otro tono u otro radio de esquina.



- `model/` — Sesion (una factura importada), Articulo (línea de
  factura + cantidad escaneada), CodigoDesconocido, EstadoArticulo.
- `data/` — base de datos local (Room/SQLite), DAOs, importador CSV.
  Todo se guarda en el propio dispositivo (sin servidor), tal como
  pediste, y sobrevive si se cierra la app a mitad de un recuento.
- `MainActivity.kt` — importación de la factura.
- `EscaneoActivity.kt` — pantalla de escaneo (la lógica principal).
- `ResumenActivity.kt` — resumen final, revisión de incidencias y
  exportación a CSV.

## Posibles mejoras futuras (no incluidas, para no sobrecargar el MVP)

- Pantalla con historial de facturas ya procesadas.
- Sonido además de vibración al escanear.
- Importación directa de `.xlsx` sin pasar por CSV.
- Botón para deshacer la última lectura por error.

Dime si quieres que añada alguna de estas.
