package com.miempresa.inventariopedidos.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.miempresa.inventariopedidos.model.CodigoDesconocido
import kotlinx.coroutines.flow.Flow

@Dao
interface CodigoDesconocidoDao {

    @Insert
    suspend fun insertar(codigo: CodigoDesconocido): Long

    @Update
    suspend fun actualizar(codigo: CodigoDesconocido)

    @Query("SELECT * FROM codigos_desconocidos WHERE sesionId = :sesionId AND codigo = :codigo LIMIT 1")
    suspend fun buscarPorCodigo(sesionId: Long, codigo: String): CodigoDesconocido?

    @Query("SELECT * FROM codigos_desconocidos WHERE sesionId = :sesionId ORDER BY fecha DESC")
    fun observarPorSesion(sesionId: Long): Flow<List<CodigoDesconocido>>

    @Query("SELECT * FROM codigos_desconocidos WHERE sesionId = :sesionId ORDER BY fecha DESC")
    suspend fun obtenerPorSesion(sesionId: Long): List<CodigoDesconocido>

    @Query("SELECT COUNT(*) FROM codigos_desconocidos WHERE sesionId = :sesionId")
    suspend fun contar(sesionId: Long): Int
}
