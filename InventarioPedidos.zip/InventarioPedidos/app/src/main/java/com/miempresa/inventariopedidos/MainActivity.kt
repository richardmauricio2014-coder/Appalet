package com.miempresa.inventariopedidos

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.miempresa.inventariopedidos.data.AppDatabase
import com.miempresa.inventariopedidos.data.CsvImporter
import com.miempresa.inventariopedidos.databinding.ActivityMainBinding
import com.miempresa.inventariopedidos.model.Sesion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val selectorArchivo = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { importarFactura(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnImportar.setOnClickListener {
            selectorArchivo.launch("*/*")
        }
    }

    private fun importarFactura(uri: Uri) {
        mostrarCargando(true)

        lifecycleScope.launch {
            try {
                val db = AppDatabase.obtener(applicationContext)
                val nombreArchivo = obtenerNombreArchivo(uri)

                val resultado = withContext(Dispatchers.IO) {
                    val sesionId = db.sesionDao().insertar(Sesion(nombreFactura = nombreArchivo))
                    val inputStream = contentResolver.openInputStream(uri)
                        ?: throw IllegalStateException("No se pudo abrir el archivo")
                    val importacion = CsvImporter.importar(inputStream, sesionId)

                    if (importacion.articulos.isEmpty()) {
                        // No había artículos válidos: eliminar la sesión creada.
                        db.sesionDao().actualizar(Sesion(id = sesionId, nombreFactura = nombreArchivo, finalizada = true))
                        null
                    } else {
                        db.articuloDao().insertarTodos(importacion.articulos)
                        Pair(sesionId, importacion.lineasIgnoradas)
                    }
                }

                mostrarCargando(false)

                if (resultado == null) {
                    Toast.makeText(
                        this@MainActivity,
                        "No se encontraron artículos válidos en el archivo. Revisa el formato (código, descripción, cantidad).",
                        Toast.LENGTH_LONG
                    ).show()
                    return@launch
                }

                val (sesionId, ignoradas) = resultado
                if (ignoradas > 0) {
                    Toast.makeText(
                        this@MainActivity,
                        "Importado. Se ignoraron $ignoradas líneas con formato incorrecto.",
                        Toast.LENGTH_LONG
                    ).show()
                }

                val intent = Intent(this@MainActivity, EscaneoActivity::class.java)
                intent.putExtra(EscaneoActivity.EXTRA_SESION_ID, sesionId)
                startActivity(intent)

            } catch (e: Exception) {
                mostrarCargando(false)
                Toast.makeText(this@MainActivity, "Error al importar el archivo: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun obtenerNombreArchivo(uri: Uri): String {
        var nombre = "factura"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val indice = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (indice >= 0 && cursor.moveToFirst()) {
                nombre = cursor.getString(indice)
            }
        }
        return nombre
    }

    private fun mostrarCargando(mostrar: Boolean) {
        binding.progressBar.visibility = if (mostrar) android.view.View.VISIBLE else android.view.View.GONE
        binding.btnImportar.isEnabled = !mostrar
    }
}
