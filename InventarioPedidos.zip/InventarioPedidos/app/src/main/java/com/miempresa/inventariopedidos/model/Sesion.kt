package com.miempresa.inventariopedidos.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Representa una recepción de mercancía asociada a una factura importada.
 */
@Entity(tableName = "sesiones")
data class Sesion(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nombreFactura: String,
    val fecha: Long = System.currentTimeMillis(),
    val finalizada: Boolean = false
)
