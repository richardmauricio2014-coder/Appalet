package com.miempresa.inventariopedidos.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.miempresa.inventariopedidos.model.Articulo
import kotlinx.coroutines.flow.Flow

@Dao
interface ArticuloDao {

    @Insert
    suspend fun insertarTodos(articulos: List<Articulo>)

    @Update
    suspend fun actualizar(articulo: Articulo)

    /** Lista en vivo de los artículos de una sesión, usada para refrescar la pantalla de escaneo. */
    @Query("SELECT * FROM articulos WHERE sesionId = :sesionId ORDER BY descripcion ASC")
    fun observarPorSesion(sesionId: Long): Flow<List<Articulo>>

    @Query("SELECT * FROM articulos WHERE sesionId = :sesionId ORDER BY descripcion ASC")
    suspend fun obtenerPorSesion(sesionId: Long): List<Articulo>

    /** Busca el artículo de la sesión cuyo código coincide exactamente con el escaneado. */
    @Query("SELECT * FROM articulos WHERE sesionId = :sesionId AND codigo = :codigo LIMIT 1")
    suspend fun buscarPorCodigo(sesionId: Long, codigo: String): Articulo?

    @Query("SELECT COUNT(*) FROM articulos WHERE sesionId = :sesionId")
    suspend fun contarTotal(sesionId: Long): Int

    @Query("SELECT COUNT(*) FROM articulos WHERE sesionId = :sesionId AND estado = 'COMPLETO'")
    suspend fun contarCompletos(sesionId: Long): Int

    @Query("SELECT COUNT(*) FROM articulos WHERE sesionId = :sesionId AND estado = 'PENDIENTE'")
    suspend fun contarPendientes(sesionId: Long): Int

    @Query("SELECT COUNT(*) FROM articulos WHERE sesionId = :sesionId AND estado = 'EXCESO'")
    suspend fun contarExceso(sesionId: Long): Int

    @Query("SELECT * FROM articulos WHERE sesionId = :sesionId AND estado != 'COMPLETO' ORDER BY estado DESC, descripcion ASC")
    suspend fun obtenerConIncidencia(sesionId: Long): List<Articulo>
}
