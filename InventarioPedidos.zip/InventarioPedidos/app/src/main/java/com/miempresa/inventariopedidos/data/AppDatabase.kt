package com.miempresa.inventariopedidos.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.miempresa.inventariopedidos.model.Articulo
import com.miempresa.inventariopedidos.model.CodigoDesconocido
import com.miempresa.inventariopedidos.model.Sesion

@Database(
    entities = [Sesion::class, Articulo::class, CodigoDesconocido::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun sesionDao(): SesionDao
    abstract fun articuloDao(): ArticuloDao
    abstract fun codigoDesconocidoDao(): CodigoDesconocidoDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun obtener(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instancia = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "inventario_pedidos.db"
                ).build()
                INSTANCE = instancia
                instancia
            }
        }
    }
}
