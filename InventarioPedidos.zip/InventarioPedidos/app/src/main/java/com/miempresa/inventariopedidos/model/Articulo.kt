package com.miempresa.inventariopedidos.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Una línea de artículo procedente de la factura importada, con el
 * seguimiento de cuántas unidades se han escaneado ya.
 */
@Entity(tableName = "articulos")
data class Articulo(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sesionId: Long,
    val codigo: String,
    val descripcion: String,
    val cantidadEsperada: Int,
    val cantidadEscaneada: Int = 0,
    val estado: EstadoArticulo = EstadoArticulo.PENDIENTE
)
