package com.miempresa.inventariopedidos.model

/**
 * Estado de un artículo dentro de una sesión de recepción.
 */
enum class EstadoArticulo {
    /** Aún no se ha escaneado ninguna unidad, o faltan por escanear. */
    PENDIENTE,

    /** Se ha escaneado exactamente la cantidad esperada según la factura. */
    COMPLETO,

    /** Se ha escaneado más unidades de las que indicaba la factura. */
    EXCESO
}
