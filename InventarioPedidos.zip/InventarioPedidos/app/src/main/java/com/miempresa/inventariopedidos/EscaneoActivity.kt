package com.miempresa.inventariopedidos

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.miempresa.inventariopedidos.adapter.ArticuloAdapter
import com.miempresa.inventariopedidos.data.AppDatabase
import com.miempresa.inventariopedidos.databinding.ActivityEscaneoBinding
import com.miempresa.inventariopedidos.model.CodigoDesconocido
import com.miempresa.inventariopedidos.model.EstadoArticulo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class EscaneoActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_SESION_ID = "extra_sesion_id"
    }

    private lateinit var binding: ActivityEscaneoBinding
    private lateinit var db: AppDatabase
    private val adapter = ArticuloAdapter()
    private var sesionId: Long = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEscaneoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sesionId = intent.getLongExtra(EXTRA_SESION_ID, -1L)
        if (sesionId == -1L) {
            finish()
            return
        }

        db = AppDatabase.obtener(applicationContext)

        binding.recyclerArticulos.layoutManager = LinearLayoutManager(this)
        binding.recyclerArticulos.adapter = adapter

        // Combina la lista de artículos y la lista de códigos desconocidos
        // para refrescar en vivo tanto la tabla como los contadores.
        lifecycleScope.launch {
            combine(
                db.articuloDao().observarPorSesion(sesionId),
                db.codigoDesconocidoDao().observarPorSesion(sesionId)
            ) { articulos, desconocidos -> Pair(articulos, desconocidos) }
                .collect { (articulos, desconocidos) ->
                    adapter.actualizar(articulos)
                    val completos = articulos.count { it.estado == EstadoArticulo.COMPLETO }
                    val exceso = articulos.count { it.estado == EstadoArticulo.EXCESO }
                    binding.txtProgreso.text = "$completos / ${articulos.size}"
                    binding.txtErrores.text = (exceso + desconocidos.size).toString()
                }
        }

        binding.inputEscaner.setOnEditorActionListener { _, actionId, event ->
            val esEnter = actionId == EditorInfo.IME_ACTION_DONE ||
                (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            if (esEnter) {
                procesarCodigo(binding.inputEscaner.text.toString())
                binding.inputEscaner.text?.clear()
                true
            } else {
                false
            }
        }

        binding.btnFinalizar.setOnClickListener { finalizarRecuento() }
    }

    override fun onResume() {
        super.onResume()
        // El campo debe mantener siempre el foco para recibir la entrada del lector.
        binding.inputEscaner.requestFocus()
    }

    private fun procesarCodigo(codigoBruto: String) {
        val codigo = codigoBruto.trim()
        if (codigo.isEmpty()) return

        lifecycleScope.launch {
            val encontrado = withContext(Dispatchers.IO) {
                val articulo = db.articuloDao().buscarPorCodigo(sesionId, codigo)
                if (articulo != null) {
                    val nuevaCantidad = articulo.cantidadEscaneada + 1
                    val nuevoEstado = if (nuevaCantidad >= articulo.cantidadEsperada) {
                        EstadoArticulo.COMPLETO
                    } else {
                        EstadoArticulo.PENDIENTE
                    }
                    // Si ya estaba completo y se vuelve a escanear, es un exceso.
                    val estadoFinal = if (articulo.estado == EstadoArticulo.COMPLETO) EstadoArticulo.EXCESO else nuevoEstado
                    db.articuloDao().actualizar(
                        articulo.copy(cantidadEscaneada = nuevaCantidad, estado = estadoFinal)
                    )
                    estadoFinal
                } else {
                    val existente = db.codigoDesconocidoDao().buscarPorCodigo(sesionId, codigo)
                    if (existente != null) {
                        db.codigoDesconocidoDao().actualizar(existente.copy(vecesEscaneado = existente.vecesEscaneado + 1))
                    } else {
                        db.codigoDesconocidoDao().insertar(CodigoDesconocido(sesionId = sesionId, codigo = codigo))
                    }
                    null
                }
            }

            if (encontrado == null) {
                vibrar(exito = false)
                Toast.makeText(this@EscaneoActivity, "Código no encontrado en la factura: $codigo", Toast.LENGTH_SHORT).show()
            } else if (encontrado == EstadoArticulo.EXCESO) {
                vibrar(exito = false)
                Toast.makeText(this@EscaneoActivity, "Cantidad de más para $codigo", Toast.LENGTH_SHORT).show()
            } else {
                vibrar(exito = true)
            }
        }
    }

    private fun vibrar(exito: Boolean) {
        val vibrador: Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        }

        val duracion = if (exito) 40L else 250L
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrador.vibrate(VibrationEffect.createOneShot(duracion, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrador.vibrate(duracion)
        }
    }

    private fun finalizarRecuento() {
        AlertDialog.Builder(this)
            .setTitle(R.string.btn_finalizar)
            .setMessage("¿Confirmas que quieres finalizar el recuento? Podrás revisar las incidencias a continuación.")
            .setPositiveButton("Finalizar") { _, _ ->
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) {
                        val sesion = db.sesionDao().obtenerPorId(sesionId)
                        if (sesion != null) {
                            db.sesionDao().actualizar(sesion.copy(finalizada = true))
                        }
                    }
                    val intent = Intent(this@EscaneoActivity, ResumenActivity::class.java)
                    intent.putExtra(ResumenActivity.EXTRA_SESION_ID, sesionId)
                    startActivity(intent)
                    finish()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
