package com.miempresa.inventariopedidos.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Código de barras escaneado que no coincide con ningún artículo de la
 * factura de la sesión actual. Se registra por separado para poder
 * revisarlo al finalizar.
 */
@Entity(tableName = "codigos_desconocidos")
data class CodigoDesconocido(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sesionId: Long,
    val codigo: String,
    val fecha: Long = System.currentTimeMillis(),
    val vecesEscaneado: Int = 1
)
