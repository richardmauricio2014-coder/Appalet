package com.miempresa.inventariopedidos.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.miempresa.inventariopedidos.model.Sesion

@Dao
interface SesionDao {

    @Insert
    suspend fun insertar(sesion: Sesion): Long

    @Update
    suspend fun actualizar(sesion: Sesion)

    @Query("SELECT * FROM sesiones WHERE id = :sesionId LIMIT 1")
    suspend fun obtenerPorId(sesionId: Long): Sesion?

    @Query("SELECT * FROM sesiones ORDER BY fecha DESC")
    suspend fun obtenerTodas(): List<Sesion>
}
