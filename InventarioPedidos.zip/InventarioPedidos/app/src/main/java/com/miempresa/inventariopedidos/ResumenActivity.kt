package com.miempresa.inventariopedidos

import android.content.ContentValues
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.miempresa.inventariopedidos.adapter.ArticuloAdapter
import com.miempresa.inventariopedidos.data.AppDatabase
import com.miempresa.inventariopedidos.databinding.ActivityResumenBinding
import com.miempresa.inventariopedidos.model.Articulo
import com.miempresa.inventariopedidos.model.EstadoArticulo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ResumenActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_SESION_ID = "extra_sesion_id"
    }

    private lateinit var binding: ActivityResumenBinding
    private lateinit var db: AppDatabase
    private val adapter = ArticuloAdapter()
    private var sesionId: Long = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResumenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sesionId = intent.getLongExtra(EXTRA_SESION_ID, -1L)
        if (sesionId == -1L) {
            finish()
            return
        }

        db = AppDatabase.obtener(applicationContext)

        binding.recyclerIncidencias.layoutManager = LinearLayoutManager(this)
        binding.recyclerIncidencias.adapter = adapter

        binding.btnCerrar.setOnClickListener { finish() }
        binding.btnExportar.setOnClickListener { exportarInforme() }

        cargarResumen()
    }

    private fun cargarResumen() {
        lifecycleScope.launch {
            val datos = withContext(Dispatchers.IO) {
                val total = db.articuloDao().contarTotal(sesionId)
                val completos = db.articuloDao().contarCompletos(sesionId)
                val pendientes = db.articuloDao().contarPendientes(sesionId)
                val exceso = db.articuloDao().contarExceso(sesionId)
                val desconocidos = db.codigoDesconocidoDao().obtenerPorSesion(sesionId)
                val incidenciasArticulos = db.articuloDao().obtenerConIncidencia(sesionId)
                Datos(total, completos, pendientes, exceso, desconocidos, incidenciasArticulos)
            }

            binding.txtTotal.text = datos.total.toString()
            binding.txtCompletos.text = datos.completos.toString()
            binding.txtPendientes.text = datos.pendientes.toString()
            binding.txtExceso.text = datos.exceso.toString()
            binding.txtDesconocidos.text = datos.desconocidos.size.toString()

            // Los códigos desconocidos se muestran en la misma lista, como
            // artículos "virtuales" en rojo, para poder revisarlos igual que
            // el resto de incidencias.
            val desconocidosComoArticulos = datos.desconocidos.mapIndexed { index, cod ->
                Articulo(
                    id = -(index + 1L),
                    sesionId = sesionId,
                    codigo = cod.codigo,
                    descripcion = "No encontrado en la factura (escaneado ${cod.vecesEscaneado}x)",
                    cantidadEsperada = 0,
                    cantidadEscaneada = cod.vecesEscaneado,
                    estado = EstadoArticulo.EXCESO
                )
            }

            val listaIncidencias = datos.incidenciasArticulos + desconocidosComoArticulos

            if (listaIncidencias.isEmpty()) {
                binding.txtSinIncidencias.visibility = android.view.View.VISIBLE
                binding.recyclerIncidencias.visibility = android.view.View.GONE
            } else {
                binding.txtSinIncidencias.visibility = android.view.View.GONE
                binding.recyclerIncidencias.visibility = android.view.View.VISIBLE
                adapter.actualizar(listaIncidencias)
            }
        }
    }

    private fun exportarInforme() {
        lifecycleScope.launch {
            val exito = withContext(Dispatchers.IO) {
                try {
                    val sesion = db.sesionDao().obtenerPorId(sesionId)
                    val incidenciasArticulos = db.articuloDao().obtenerConIncidencia(sesionId)
                    val desconocidos = db.codigoDesconocidoDao().obtenerPorSesion(sesionId)

                    val sb = StringBuilder()
                    sb.append("codigo,descripcion,cantidad_esperada,cantidad_escaneada,estado\n")
                    incidenciasArticulos.forEach {
                        sb.append("${it.codigo},\"${it.descripcion}\",${it.cantidadEsperada},${it.cantidadEscaneada},${it.estado}\n")
                    }
                    desconocidos.forEach {
                        sb.append("${it.codigo},\"NO ENCONTRADO EN FACTURA\",0,${it.vecesEscaneado},DESCONOCIDO\n")
                    }

                    val marcaTiempo = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                    val nombreArchivo = "incidencias_${sesion?.nombreFactura?.substringBeforeLast(".") ?: "sesion"}_$marcaTiempo.csv"

                    guardarCsv(nombreArchivo, sb.toString())
                    true
                } catch (e: Exception) {
                    false
                }
            }

            Toast.makeText(
                this@ResumenActivity,
                if (exito) "Informe exportado en Descargas: incidencias" else "No se pudo exportar el informe",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    /** Guarda el CSV en la carpeta pública de Descargas (API 29+) o en el
     * almacenamiento propio de la app en versiones anteriores. */
    private fun guardarCsv(nombreArchivo: String, contenido: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = contentResolver
            val valores = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, nombreArchivo)
                put(MediaStore.Downloads.MIME_TYPE, "text/csv")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, valores)
                ?: throw IllegalStateException("No se pudo crear el archivo")
            val salida: OutputStream = resolver.openOutputStream(uri)
                ?: throw IllegalStateException("No se pudo abrir el archivo")
            salida.use { it.write(contenido.toByteArray(Charsets.UTF_8)) }
        } else {
            val carpeta = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            val archivo = File(carpeta, nombreArchivo)
            archivo.writeText(contenido, Charsets.UTF_8)
        }
    }

    private data class Datos(
        val total: Int,
        val completos: Int,
        val pendientes: Int,
        val exceso: Int,
        val desconocidos: List<com.miempresa.inventariopedidos.model.CodigoDesconocido>,
        val incidenciasArticulos: List<Articulo>
    )
}
