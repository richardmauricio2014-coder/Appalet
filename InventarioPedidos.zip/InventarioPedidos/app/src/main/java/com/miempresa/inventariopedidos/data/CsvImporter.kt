package com.miempresa.inventariopedidos.data

import com.miempresa.inventariopedidos.model.Articulo
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader

/**
 * Importa la factura en formato CSV (exportada desde Excel).
 *
 * Se espera una primera fila de cabecera y luego, por cada línea, tres
 * columnas: código, descripción y cantidad. Admite separador por coma (,)
 * o punto y coma (;), que es el habitual al exportar desde Excel en español.
 *
 * Si el archivo original es .xlsx, desde Excel: "Guardar como" -> "CSV UTF-8
 * (delimitado por comas)".
 */
object CsvImporter {

    class ResultadoImportacion(
        val articulos: List<Articulo>,
        val lineasIgnoradas: Int
    )

    fun importar(inputStream: InputStream, sesionId: Long): ResultadoImportacion {
        val lector = BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8))
        val lineas = lector.readLines().filter { it.isNotBlank() }
        lector.close()

        if (lineas.isEmpty()) {
            return ResultadoImportacion(emptyList(), 0)
        }

        val separador = detectarSeparador(lineas.first())

        val articulos = mutableListOf<Articulo>()
        var ignoradas = 0

        // La primera línea se asume cabecera (código, descripción, cantidad...) y se salta.
        for (i in 1 until lineas.size) {
            val columnas = dividirLineaCsv(lineas[i], separador)
            if (columnas.size < 3) {
                ignoradas++
                continue
            }

            val codigo = columnas[0].trim()
            val descripcion = columnas[1].trim()
            val cantidad = columnas[2].trim().toIntOrNull()

            if (codigo.isEmpty() || cantidad == null || cantidad <= 0) {
                ignoradas++
                continue
            }

            articulos.add(
                Articulo(
                    sesionId = sesionId,
                    codigo = codigo,
                    descripcion = descripcion,
                    cantidadEsperada = cantidad
                )
            )
        }

        return ResultadoImportacion(articulos, ignoradas)
    }

    private fun detectarSeparador(cabecera: String): Char {
        val comas = cabecera.count { it == ',' }
        val puntoYComa = cabecera.count { it == ';' }
        return if (puntoYComa > comas) ';' else ','
    }

    /** Divide una línea CSV respetando campos entre comillas dobles. */
    private fun dividirLineaCsv(linea: String, separador: Char): List<String> {
        val campos = mutableListOf<String>()
        val actual = StringBuilder()
        var dentroDeComillas = false

        var i = 0
        while (i < linea.length) {
            val c = linea[i]
            when {
                c == '"' -> dentroDeComillas = !dentroDeComillas
                c == separador && !dentroDeComillas -> {
                    campos.add(actual.toString())
                    actual.clear()
                }
                else -> actual.append(c)
            }
            i++
        }
        campos.add(actual.toString())
        return campos
    }
}
