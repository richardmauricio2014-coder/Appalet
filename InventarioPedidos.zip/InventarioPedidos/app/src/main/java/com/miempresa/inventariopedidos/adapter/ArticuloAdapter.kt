package com.miempresa.inventariopedidos.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.miempresa.inventariopedidos.R
import com.miempresa.inventariopedidos.model.Articulo
import com.miempresa.inventariopedidos.model.EstadoArticulo

class ArticuloAdapter : RecyclerView.Adapter<ArticuloAdapter.ArticuloViewHolder>() {

    private val articulos = mutableListOf<Articulo>()

    fun actualizar(nuevaLista: List<Articulo>) {
        val diff = DiffUtil.calculateDiff(DiffCallback(articulos, nuevaLista))
        articulos.clear()
        articulos.addAll(nuevaLista)
        diff.dispatchUpdatesTo(this)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ArticuloViewHolder {
        val vista = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_articulo, parent, false)
        return ArticuloViewHolder(vista)
    }

    override fun onBindViewHolder(holder: ArticuloViewHolder, position: Int) {
        holder.bind(articulos[position])
    }

    override fun getItemCount(): Int = articulos.size

    class ArticuloViewHolder(itemView: android.view.View) : RecyclerView.ViewHolder(itemView) {
        private val indicador = itemView.findViewById<android.view.View>(R.id.indicadorEstado)
        private val txtDescripcion = itemView.findViewById<TextView>(R.id.txtDescripcion)
        private val txtCodigo = itemView.findViewById<TextView>(R.id.txtCodigo)
        private val txtCantidad = itemView.findViewById<TextView>(R.id.txtCantidad)

        fun bind(articulo: Articulo) {
            val contexto = itemView.context
            txtDescripcion.text = articulo.descripcion
            txtCodigo.text = "Código: ${articulo.codigo}"
            txtCantidad.text = "${articulo.cantidadEscaneada} / ${articulo.cantidadEsperada}"

            val colorEstado = when (articulo.estado) {
                EstadoArticulo.PENDIENTE -> R.color.estado_pendiente
                EstadoArticulo.COMPLETO -> R.color.estado_completo
                EstadoArticulo.EXCESO -> R.color.estado_error
            }
            indicador.backgroundTintList = ContextCompat.getColorStateList(contexto, colorEstado)
            txtCantidad.setTextColor(ContextCompat.getColor(contexto, colorEstado))
        }
    }

    private class DiffCallback(
        private val vieja: List<Articulo>,
        private val nueva: List<Articulo>
    ) : DiffUtil.Callback() {
        override fun getOldListSize() = vieja.size
        override fun getNewListSize() = nueva.size
        override fun areItemsTheSame(oldPos: Int, newPos: Int) = vieja[oldPos].id == nueva[newPos].id
        override fun areContentsTheSame(oldPos: Int, newPos: Int) = vieja[oldPos] == nueva[newPos]
    }
}
