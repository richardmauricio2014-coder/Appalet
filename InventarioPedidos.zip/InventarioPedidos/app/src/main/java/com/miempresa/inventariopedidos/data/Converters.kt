package com.miempresa.inventariopedidos.data

import androidx.room.TypeConverter
import com.miempresa.inventariopedidos.model.EstadoArticulo

class Converters {
    @TypeConverter
    fun fromEstado(estado: EstadoArticulo): String = estado.name

    @TypeConverter
    fun toEstado(valor: String): EstadoArticulo = EstadoArticulo.valueOf(valor)
}
